#!/usr/bin/env python
# coding: utf-8

import os
for i in range(1, 21):
    os.system("mkdir -p /home/dashu/icecast/data/cnv%d/data" % (i,))
    os.system("mkdir -p /home/dashu/icecast/data/cnv%d/merged" % (i,))
for i in range(1, 10):
    os.system("mkdir -p /home/dashu/icecast/data/interview%d/data" % (i,))
    os.system("mkdir -p /home/dashu/icecast/data/interview%d/merged" % (i,))
os.system("chown -R dashu:dashu /home/dashu/icecast/data")
