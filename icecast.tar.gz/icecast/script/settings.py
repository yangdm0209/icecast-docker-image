#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os

WHALE_MOUNTS = (
    '/interview6.mp3', '/interview7.mp3', '/interview8.mp3', '/interview9.mp3', '/v11.mp3', '/v12.mp3', '/v13.mp3',
    '/v14.mp3', '/v15.mp3', '/v16.mp3', '/v17.mp3', '/v18.mp3', '/v19.mp3', '/v20.mp3')

LOG_FILE = '/home/dashu/icecast/log/script.log'
# dump_file为/tmp/example%Y%m%d%H%M%S.mp3
DUMP_FILE_PATH = '/home/dashu/icecast/data/'
DUMP_FILE_SUFFIX = '.mp3'
WEIXIN_ROBOT_STATUS_CONF = '/home/dashu/WeixinRobot/conf/'
# 线下REDIS 配置
REDIS_HOST = '127.0.0.1'
REDIS_PORT = 6379
REDIS_DB_DASHU = 0
REDIS_DB_WHALE = 8
REDIS_PASSWORD = '6aa66d9078382fd'

# 线上REDIS 配置
# REDIS_HOST='637a5de33f3c48c8.m.cnbja.kvstore.aliyuncs.com'
# REDIS_PORT=6379
# REDIS_DB=0
# REDIS_PASSWORD='637a5de33f3c48c8:M4Ftu9Pn4e1l51c'


# qiniu url前缀
QINIU_URL = 'http://qiniucdn.dashuqinzi.com/'

# 线下
HOST_DASHU = 'apidev'
HOST_WHALE = 'whaledev'


# 线上
# HOST_DASHU='api'
# HOST_WHALE='whale'

# voice线下api接口
def get_voice_status_url(mount):
    if mount in WHALE_MOUNTS:
        return 'http://%s.dashuqinzi.com/mount/get/status' % HOST_WHALE
    else:
        return 'http://%s.dashuqinzi.com/mount/get/status' % HOST_DASHU


def update_voice_status_url(mount):
    if mount in WHALE_MOUNTS:
        return 'http://%s.dashuqinzi.com/mount/update/status' % HOST_WHALE
    else:
        return 'http://%s.dashuqinzi.com/mount/update/status' % HOST_DASHU


def insert_voice_url(mount):
    if mount in WHALE_MOUNTS:
        return 'http://%s.dashuqinzi.com/voice/insert/url' % HOST_WHALE
    else:
        return 'http://%s.dashuqinzi.com/voice/insert/url' % HOST_DASHU


def get_meeting_status_url(mount):
    if mount in WHALE_MOUNTS:
        return 'http://%s.dashuqinzi.com/meeting/get_status' % HOST_WHALE
    else:
        return 'http://%s.dashuqinzi.com/meeting/get_status' % HOST_DASHU


def update_meeting_status_url(mount):
    if mount in WHALE_MOUNTS:
        return 'http://%s.dashuqinzi.com/meeting/update_status' % HOST_WHALE
    else:
        return 'http://%s.dashuqinzi.com/meeting/update_status' % HOST_DASHU


def insert_meeting_url(mount):
    if mount in WHALE_MOUNTS:
        return 'http://%s.dashuqinzi.com/meeting/insert_url' % HOST_WHALE
    else:
        return 'http://%s.dashuqinzi.com/meeting/insert_url' % HOST_DASHU

# voice线下api接口
# GET_VOICE_STATUS_URL = 'http://apidev.dashuqinzi.com/mount/get/status'
# UPDATE_VOICE_STATUS_URL = 'http://apidev.dashuqinzi.com/mount/update/status'
# INSERT_VOICE_URL_URL = 'http://apidev.dashuqinzi.com/voice/insert/url'

# voice线上api接口
# GET_VOICE_STATUS_URL='http://api.dashuqinzi.com/mount/get/status'
# UPDATE_VOICE_STATUS_URL='http://api.dashuqinzi.com/mount/update/status'
# INSERT_VOICE_URL_URL='http://api.dashuqinzi.com/voice/insert/url'

# meeting线下api接口
# GET_MEETING_STATUS_URL = 'http://apidev.dashuqinzi.com/meeting/get_status'
# UPDATE_MEETING_STATUS_URL = 'http://apidev.dashuqinzi.com/meeting/update_status'
# INSERT_MEETING_URL_URL = 'http://apidev.dashuqinzi.com/meeting/insert_url'

# meeting线上api接口
# GET_MEETING_STATUS_URL='http://api.dashuqinzi.com/meeting/get_status'
# UPDATE_MEETING_STATUS_URL='http://api.dashuqinzi.com/meeting/update_status'
# INSERT_MEETING_URL_URL='http://api.dashuqinzi.com/meeting/insert_url'
