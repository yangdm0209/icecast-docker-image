#!/usr/bin/env python
# -*- coding: utf-8 -*-

import hashlib
import random
import time
import datetime

import qiniu

def qiniu_upload(tmp_file_path):
    q = qiniu.Auth('ZJOlhbYPqmO0LABMjLKtfjhO9RzMQqh27nbg2pil', 'Jr9b-15M2dSEegsB3WoAcnMpsveEIcKJtOZFemZH')
    key = datetime.datetime.now().strftime("%Y/%m/%d/")
    key += hashlib.md5(str(time.time()) + str(random.randint(1111, 9999))).hexdigest()
    token = q.upload_token('dashu', key)

    mime_type = "audio/mp3"
    ret, info = qiniu.put_file(token, key, tmp_file_path, mime_type=mime_type)
    print ret
    print info
    if ret['key'] == key:
        return key
    else:
        return False

def usage():
    print "-i 输入文件"
    print "-v 课程id"
    print "-h 帮助"

if __name__ == "__main__":
    '''
    import sys, getopt
    opts, args = getopt.getopt(sys.argv[1:], "hi:v:")

    input_file=""
    vid=""

    for op, value in opts:
        if op == "-i":
            input_file = value
        elif op == "-v":
            vid = value
        elif op == "-h":
            usage()
            sys.exit()
    '''
    input_file="/home/dashu/icecast/data/v2/data/1811_dump20160201115920.mp3"
    key = qiniu_upload(input_file)
    print key

