#!/usr/bin/env python
# -*- coding: utf-8 -*-
from settings import *
import logging
import logging.handlers
import redis
import urllib
import urllib2

handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1024 * 1024, backupCount=5)  # 实例化handler
fmt = '%(asctime)s - %(filename)s:%(lineno)s - %(name)s - %(message)s'
formatter = logging.Formatter(fmt)  # 实例化formatter
handler.setFormatter(formatter)  # 为handler添加formatter

logger = logging.getLogger('icecast')  # 获取名为icecast的logger
logger.addHandler(handler)  # 为logger添加handler
logger.setLevel(logging.DEBUG)


def create_redis_connection(mount):
    db = REDIS_DB_DASHU
    if mount in WHALE_MOUNTS:
        db = REDIS_DB_WHALE
    return redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=db, password=REDIS_PASSWORD)


def post(url, data):
    print 'in post, url:', post
    req = urllib2.Request(url)
    data = urllib.urlencode(data)
    # enable cookie
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
    response = opener.open(req, data)
    return response.read()
