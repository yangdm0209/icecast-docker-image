#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import sys
from settings import *
from util import *
import hashlib
import random
import time
import datetime
import os
import qiniu
import string
import redis
import json
from os.path import getsize


def check_status(mount, vid):
    data = {'mount': mount, 'vid': vid}
    ret = post(get_voice_status_url(mount), data)
    result = False

    if ret:
        print ret
        ret_obj = json.loads(ret)
        if ret_obj['res'] == 'success' and ret_obj['data']['status'] == 'start':
            logger.info('mount:%s,vid:%d status ok' % (mount, vid))
            result = True
    else:
        logger.info('mount:%s,vid:%d not exist or status is not start' % (mount, vid))
    return result


def update_mount_status_stop(mount, vid):
    data = {'mount': mount, 'vid': vid, 'status': 'stop'}
    ret = post(update_voice_status_url(mount), data)


def insert_voice_voice_url(vid, url, duration, mount):
    data = {'vid': vid, 'url': url, 'duration': duration}
    ret = post(insert_voice_url(mount), data)


def check_meeting_status(mount, mid):
    data = {'mount': mount, 'mid': mid}
    ret = post(get_meeting_status_url(mount), data)
    result = False

    if ret:
        print ret
        ret_obj = json.loads(ret)
        if ret_obj['res'] == 'success' and ret_obj['data']['status'] == 'start':
            logger.info('mount:%s,mid:%d status ok' % (mount, mid))
            result = True
    else:
        logger.info('mount:%s,mid:%d not exist or status is not start' % (mount, mid))
    return result


def update_meeting_status_stop(mount, mid):
    data = {'mount': mount, 'mid': mid, 'status': 'stop'}
    ret = post(update_meeting_status_url(mount), data)


def insert_meeting_meeting_url(mid, url, duration, mount):
    data = {'mid': mid, 'url': url, 'duration': duration}
    ret = post(insert_meeting_url(mount), data)


def qiniu_upload(tmp_file_path):
    q = qiniu.Auth('ZJOlhbYPqmO0LABMjLKtfjhO9RzMQqh27nbg2pil', 'Jr9b-15M2dSEegsB3WoAcnMpsveEIcKJtOZFemZH')
    key = datetime.datetime.now().strftime("%Y/%m/%d/")
    key += hashlib.md5(str(time.time()) + str(random.randint(1111, 9999))).hexdigest()
    token = q.upload_token('dashu', key)

    mime_type = "audio/mp3"
    ret, info = qiniu.put_file(token, key, tmp_file_path, mime_type=mime_type)

    if ret['key'] == key:
        return key
    else:
        return False


def qiniu_upload_mp4(tmp_file_path):
    q = qiniu.Auth('ZJOlhbYPqmO0LABMjLKtfjhO9RzMQqh27nbg2pil', 'Jr9b-15M2dSEegsB3WoAcnMpsveEIcKJtOZFemZH')
    key = datetime.datetime.now().strftime("%Y/%m/%d/")
    key += hashlib.md5(str(time.time()) + str(random.randint(1111, 9999))).hexdigest() + ".mp4"
    token = q.upload_token('dashu', key)

    mime_type = "video/mp4"
    ret, info = qiniu.put_file(token, key, tmp_file_path, mime_type=mime_type)

    if ret['key'] == key:
        return key
    else:
        return False


'''''
比较文件名称
'''''


def compare(x, y):
    '''
    stat_x = os.stat(x)
    stat_y = os.stat(y)
    if stat_x.st_ctime < stat_y.st_ctime:
        return -1
    elif stat_x.st_ctime > stat_y.st_ctime:
        return 1
    else:
        return 0
    '''
    return cmp(x, y)


def get_mount_files(data_path, prefix, suffix, merged_path):
    '''''
    打印一个目录下的所有文件夹和文件
    '''
    # 所有文件夹，第一个字段是次目录的级别
    dirList = []
    # 所有文件
    fileList = []

    files = os.listdir(data_path)
    # 先添加目录级别
    for f in files:
        # 添加文件
        if len(f) - len(prefix) - len(suffix) != 18:
            continue
        if f.startswith(prefix) and f.endswith(suffix):
            old_file = data_path + f
            new_file = merged_path + f
            command = "cp %s %s" % (old_file, new_file)
            print command
            os.system(command)
            fileList.append(new_file)
            command = "cp %s.meta %s.meta" % (old_file, new_file)
            print command
            os.system(command)

    fileList.sort(compare)
    for f in fileList:
        print f
    return fileList


def merge_mount_files(fileList, merged_file, timeline_file):
    chunksize = 1024

    mp3_of = open(merged_file, "wb");
    timeline_of = open(timeline_file, "w+");

    base_time_offset = 0;
    for f in fileList:
        fin = open(f, "rb")
        while True:
            chunk = fin.read(chunksize)
            if chunk:
                mp3_of.write(chunk)
            else:
                break
        fin.close()
        metadata_dump_file = f + '.meta'
        write_timeline_file(metadata_dump_file, base_time_offset, timeline_of);
        size = getsize(f);
        print size
        base_time_offset = base_time_offset + int(size * 8.0 / 64);
        print "base_time_offset:", base_time_offset
    mp3_of.close();
    timeline_of.close();
    timeline_of.close();
    return 0;


def write_timeline_file(meta_dump_file, base_time_offset, timeline_of):
    metadata_if = open(meta_dump_file, "r");

    done = 0
    while not done:
        line = metadata_if.readline()
        if (line != ''):
            print line
            item = line.split('\t', 1);
            try:
                meta_int_no = string.atoi(item[0])
                meta = item[1]
                time_offset = base_time_offset + 1000 * meta_int_no;
                write_line = "%d\t%s" % (time_offset, meta);
                timeline_of.write(write_line);
            except Exception, ex:
                print Exception, ":", ex

        else:
            done = 1
    metadata_if.close();


def merge_meeting_mount_files(fileList, merged_file, timeline_file):
    chunksize = 1024

    mp3_of = open(merged_file, "wb");
    timeline_of = open(timeline_file, "w+");

    base_time_offset = 0;
    for f in fileList:
        fin = open(f, "rb")
        while True:
            chunk = fin.read(chunksize)
            if chunk:
                mp3_of.write(chunk)
            else:
                break
        fin.close()
        metadata_dump_file = f + '.meta'
        write_meeting_timeline_file(metadata_dump_file, base_time_offset, timeline_of);
        size = getsize(f);
        print size
        base_time_offset = base_time_offset + int(size * 8.0 / 64);
        print "base_time_offset:", base_time_offset
    mp3_of.close();
    timeline_of.close();
    timeline_of.close();
    return 0;


def write_meeting_timeline_file(meta_dump_file, base_time_offset, timeline_of):
    metadata_if = open(meta_dump_file, "r");

    done = 0
    while not done:
        line = metadata_if.readline()
        if (line != ''):
            print line
            item = line.split('\t', 1);
            try:
                meta_int_no = string.atoi(item[0])
                meta = item[1]
                time_offset = base_time_offset + 1000 * meta_int_no;
                write_line = "%d\t%s" % (time_offset, meta);
                timeline_of.write(write_line);
            except Exception, ex:
                print Exception, ":", ex

        else:
            done = 1
    metadata_if.close();


def remove_invalid_frame(merged_file):
    command = "/home/dashu/icecast/script/mp3val %s -f" % (merged_file)
    os.system(command)


def insert_time_line(timeline_file, vid, mount):
    key = "dashu:voice:timeline:%s" % vid
    redis_client = create_redis_connection(mount)
    redis_client.delete(key)
    fin = open(timeline_file)
    pipeline = redis_client.pipeline()
    for line in fin:
        try:
            created_at, command = line.split('\t', 1)
            command_obj = json.loads(command)
            value = "{\"body\":\"\"\"%s\"\"\",\"type\":%s,\"act\":%s,\"uid\":%s,\"time\":%s}" % (
                command_obj["body"], command_obj["type"], command_obj["act"], command_obj["uid"], created_at)
            logger.info('insert_time_line:before lpush')
            # ret=redis_client.lpush(key,value)
            ret = pipeline.lpush(key, value)
            logger.info('insert_time_line:key:%s,value:%s,ret:%s' % (key, value, ret))
        except Exception, ex:
            print Exception, ":", ex
    ret = pipeline.execute()
    logger.info('insert_time_line:pipeline:%s' % (ret))
    fin.close()


def get_mp4_url(playback_url, merged_data_path):
    m3u8_name = playback_url.split("/")
    mp4_name = merged_data_path + m3u8_name[3].split(".")[0] + ".mp4"
    if os.path.exists(mp4_name) == False:
        command = "ffmpeg -i %s -c copy -bsf:a aac_adtstoasc %s" % (playback_url, mp4_name)
        print command
        os.system(command)

    key = qiniu_upload_mp4(mp4_name)
    url = QINIU_URL + key
    if key != False:
        return url
    else:
        logger.info('上传到七牛失败')
        return None


def insert_meeting_time_line(timeline_file, vid, merged_path, mount):
    key = "dashu:meeting:timeline:%s" % vid
    redis_client = create_redis_connection(mount)
    redis_client.delete(key)
    pipeline = redis_client.pipeline()
    fin = open(timeline_file)
    for line in fin:
        try:
            created_at, command = line.split('\t', 1)
            command_obj = json.loads(command)
            if command_obj["act"] == 13:
                body_obj = json.loads(command_obj["body"])
                if body_obj["order"] == 1:  # start
                    playback_url = body_obj["playback_url"]
                    mp4_url = get_mp4_url(playback_url, merged_path)
                    body_str = "{\"stime\":\"%s\",\"endtime\":\"%s\",\"url\":\"%s\"}" % (
                        body_obj["stime"], body_obj["endtime"], mp4_url)
                    value = "{\"body\":\"\"\"%s\"\"\",\"type\":%s,\"act\":7,\"is_live\":1,\"uid\":%s,\"time\":%s}" % (
                        body_str, command_obj["type"], command_obj["uid"], created_at)

                else:  # stop
                    playback_url = body_obj["playback_url"]
                    body_str = "{\"stime\":\"%s\",\"endtime\":\"%s\",\"url\":\"\"}" % (
                        body_obj["stime"], body_obj["endtime"])
                    value = "{\"body\":\"\"\"%s\"\"\",\"type\":%s,\"act\":7,\"is_live\":1,\"uid\":%s,\"time\":%s}" % (
                        body_str, command_obj["type"], command_obj["uid"], created_at)
            else:
                # print "command_obj111111:",command_obj['body']
                # if  command_obj["type"]!=2:
                #	body_obj= json.loads(command_obj["body"])

                value = "{\"body\":\"\"\"%s\"\"\",\"type\":%s,\"act\":%s,\"uid\":%s,\"time\":%s}" % (
                    command_obj["body"], command_obj["type"], command_obj["act"], command_obj["uid"], created_at)
            logger.info('insert_meeting_time_line:before lpush')
            # ret=redis_client.lpush(key,value)
            ret = pipeline.lpush(key, value)
            logger.info('insert_meeting_time_line:key:%s,value:%s,ret:%s' % (key, value, ret))
        except Exception, ex:
            print Exception, ":", ex

    ret = pipeline.execute()
    logger.info('insert_meeting_time_line:pipeline:%s' % (ret))
    fin.close()


def cal_voice_duration(voice_file):
    size = getsize(voice_file);
    duration = int(size / 8000)
    h = int(duration / 3600);
    m = int((duration - h * 3600) / 60);
    s = duration - h * 3600 - m * 60;
    total_time_h = "";
    total_time_m = "";
    total_time_s = "";
    if (h == 0):
        total_time_h = "00";
    elif (h > 0 and h < 10):
        total_time_h = "0%d" % (h);
    else:
        total_time_h = str(h);
    if (m == 0):
        total_time_m = "00";
    elif (m > 0 and m < 10):
        total_time_m = "0%d" % (m);
    else:
        total_time_m = str(m);

    if (s == 0):
        total_time_s = "00";
    elif (s > 0 and s < 10):
        total_time_s = "0%d" % (s);
    else:
        total_time_s = str(s);

    audio_total_time = total_time_h + ":" + total_time_m + ":" + total_time_s;
    return audio_total_time


def cal_meeting_voice_duration(voice_file):
    size = getsize(voice_file);
    duration = int(size / 8000)
    h = int(duration / 3600);
    m = int((duration - h * 3600) / 60);
    s = duration - h * 3600 - m * 60;
    total_time_h = "";
    total_time_m = "";
    total_time_s = "";
    if (h == 0):
        total_time_h = "00";
    elif (h > 0 and h < 10):
        total_time_h = "0%d" % (h);
    else:
        total_time_h = str(h);
    if (m == 0):
        total_time_m = "00";
    elif (m > 0 and m < 10):
        total_time_m = "0%d" % (m);
    else:
        total_time_m = str(m);

    if (s == 0):
        total_time_s = "00";
    elif (s > 0 and s < 10):
        total_time_s = "0%d" % (s);
    else:
        total_time_s = str(s);

    audio_total_time = total_time_h + ":" + total_time_m + ":" + total_time_s;
    return audio_total_time


def stop_weixin_robot(mount, vid):
    logger.info("in stop_weixin_robot")

    mount_trimed = mount.lstrip('/')
    item = mount_trimed.split('.')
    mount_trimed = item[0]

    status_filename = WEIXIN_ROBOT_STATUS_CONF + "status.conf_" + mount_trimed + "_" + vid

    status_of = open(status_filename, "w")
    status_line = mount_trimed + "_" + vid + "_status:stop\n"
    status_of.write(status_line)
    status_of.close()
    logger.info("write status ok")


if __name__ == "__main__":
    argc = len(sys.argv)
    if argc != 3:
        logger.info('argc len must 3')
        sys.exit(1)
    mount = sys.argv[1]
    mount_trimed = mount.lstrip('/')
    item = mount_trimed.split('.')
    mount_trimed = item[0]
    vid = sys.argv[2]
    mid = sys.argv[2]
    if mount[:10] == "/interview":
        ret = check_meeting_status(mount, string.atoi(mid))
    # if ret==False:
    #	logger.info('meeting status error')
    #	sys.exit(1)
    else:
        ret = check_status(mount, string.atoi(vid))
    # if ret==False:
    #	logger.info('voice status error')
    #	sys.exit(1)

    data_path = DUMP_FILE_PATH + mount_trimed + '/data/'
    merged_path = DUMP_FILE_PATH + mount_trimed + '/merged/'
    prefix = '%s_' % (vid)
    suffix = '.mp3'
    fileList = get_mount_files(data_path, prefix, suffix, merged_path);

    # 从mp3文件中提取出timeline
    merged_file = DUMP_FILE_PATH + mount_trimed + '/merged/' + vid + '_dump' + DUMP_FILE_SUFFIX
    timeline_file = DUMP_FILE_PATH + mount_trimed + '/merged/' + vid + '_dump.timeline'
    if mount[:10] == "/interview":
        merge_meeting_mount_files(fileList, merged_file, timeline_file)
    else:
        merge_mount_files(fileList, merged_file, timeline_file)
    logger.info('after parse mp3')
    remove_invalid_frame(merged_file)
    logger.info('after remove invalid frame')
    # 将解析后的mp3上传的七牛
    if mount[:10] == "/interview":
        before_src = merged_file
        merged_file = before_src + ".mew.mp3"
        os.system("ffmpeg -i %s -ar 44100 %s" % (before_src, merged_file))
    key = qiniu_upload(merged_file)
    url = QINIU_URL + key
    logger.info('qiniu_upload:key:%s' % (key,))
    print key
    if key != False:
        if mount[:10] == "/interview":
            duration = cal_meeting_voice_duration(merged_file)
            insert_meeting_meeting_url(string.atoi(mid), url, duration, mount)
            # 向redis插入时间轴
            insert_meeting_time_line(timeline_file, mid, merged_path, mount)
            # 更新数据库中课程的状态
            update_meeting_status_stop(mount, string.atoi(mid))
            stop_weixin_robot(mount, mid)
        else:
            duration = cal_voice_duration(merged_file)
            insert_voice_voice_url(string.atoi(vid), url, duration, mount)
            # 向redis插入时间轴
            insert_time_line(timeline_file, vid, mount)
            # 更新数据库中课程的状态
            update_mount_status_stop(mount, string.atoi(vid))
            stop_weixin_robot(mount, vid)
    else:
        logger.info('上传到七牛失败')
