#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import sys
import string
from settings import *
from util import *
import json


def voice_on_start(mount, vid):
    logger.info('in voice_on_start:%s,%d' % (mount, vid))
    data = {'mount': mount, 'vid': vid}
    ret = post(get_voice_status_url(mount), data)
    if ret:
        print ret
        ret_obj = json.loads(ret)
        if ret_obj['res'] == 'success' and ret_obj['data']['status'] == '':
            data = {'mount': mount, 'vid': vid, 'status': 'start'}
            ret = post(update_voice_status_url(mount), data)
            logger.info(ret)
            ret_obj = json.loads(ret)


def meeting_on_start(mount, mid):
    logger.info('in meeting_on_start:%s,%d' % (mount, mid))
    data = {'mount': mount, 'mid': mid}
    ret = post(get_meeting_status_url(mount), data)
    if ret:
        print ret
        ret_obj = json.loads(ret)
        if ret_obj['res'] == 'success' and ret_obj['data']['status'] == '':
            data = {'mount': mount, 'mid': mid, 'status': 'start'}
            ret = post(update_meeting_status_url(mount), data)
            logger.info(ret)
            ret_obj = json.loads(ret)


def start_weixin_robot(mount, vid):
    logger.info("in start_weixin_robot")

    mount_trimed = mount.lstrip('/')
    item = mount_trimed.split('.')
    mount_trimed = item[0]

    status_filename = WEIXIN_ROBOT_STATUS_CONF + "status.conf_" + mount_trimed + "_" + vid
    if os.path.exists(status_filename):
        os.remove(status_filename)

    status_of = open(status_filename, "w")
    status_line = mount_trimed + "_" + vid + "_status:start\n"
    status_of.write(status_line)
    status_of.close()
    logger.info("write status ok")


if __name__ == "__main__":
    argc = len(sys.argv)
    if argc != 3:
        logger.info('argc len must 3')
        exit
    mount = sys.argv[1]
    print mount[:10]
    if mount[:10] == "/interview":
        mid = sys.argv[2]
        meeting_on_start(mount, string.atoi(mid))
        start_weixin_robot(mount, mid)
    else:
        vid = sys.argv[2]
        voice_on_start(mount, string.atoi(vid))
        start_weixin_robot(mount, vid)
